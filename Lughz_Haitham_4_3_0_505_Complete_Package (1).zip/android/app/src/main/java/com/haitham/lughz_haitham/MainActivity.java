package com.haitham.lughz_haitham;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
