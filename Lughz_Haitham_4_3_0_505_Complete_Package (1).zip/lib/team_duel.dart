import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

String _teamArabicDigits(int value) {
  const digits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  return value.toString().split('').map((c) => digits[int.parse(c)]).join();
}

class TeamDuelPage extends StatefulWidget {
  const TeamDuelPage({super.key});

  @override
  State<TeamDuelPage> createState() => _TeamDuelPageState();
}

class _TeamDuelPageState extends State<TeamDuelPage> {
  final name = TextEditingController();
  final invite = TextEditingController();
  final server = TextEditingController(
    text: 'https://hitham.hithamadal.workers.dev',
  );
  final client = HttpClient()..userAgent = 'LughzHaitham/4.3.0';

  String teamId = 'red';
  String code = '', pid = '', token = '', error = '';
  Map<String, dynamic>? state;
  Timer? timer;
  bool loading = false, polling = false;
  int rounds = 10, seconds = 15;

  @override
  void initState() {
    super.initState();
    timer = Timer.periodic(const Duration(milliseconds: 700), (_) => _poll());
  }

  @override
  void dispose() {
    timer?.cancel();
    client.close(force: true);
    name.dispose();
    invite.dispose();
    server.dispose();
    super.dispose();
  }

  Future<Map<String, dynamic>> _request(
    String path, [
    Map<String, dynamic> extra = const {},
  ]) async {
    final base = server.text.trim().replaceAll(RegExp(r'/+$'), '');
    final request = await client
        .postUrl(Uri.parse('$base/api/$path'))
        .timeout(const Duration(seconds: 12));
    request.headers.contentType = ContentType.json;
    request.write(jsonEncode({
      'code': code,
      'pid': pid,
      'token': token,
      ...extra,
    }));
    final response = await request.close().timeout(const Duration(seconds: 12));
    return jsonDecode(await utf8.decoder.bind(response).join())
        as Map<String, dynamic>;
  }

  Future<void> _action(
    String path, [
    Map<String, dynamic> extra = const {},
  ]) async {
    if (loading) return;
    setState(() {
      loading = true;
      error = '';
    });
    try {
      final result = await _request(path, extra);
      if (!mounted) return;
      if (result['ok'] != true) {
        setState(() => error = result['error']?.toString() ?? 'حدث خطأ');
      } else {
        setState(() {
          code = result['code']?.toString() ?? code;
          pid = result['pid']?.toString() ?? pid;
          token = result['token']?.toString() ?? token;
          state = result;
          error = '';
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() => error = 'تعذر الاتصال. تحقق من الإنترنت وعنوان الخادم.');
      }
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _poll() async {
    if (pid.isEmpty || polling || loading) return;
    polling = true;
    try {
      final result = await _request('state');
      if (mounted && result['ok'] == true) {
        setState(() => state = result);
      }
    } catch (_) {
      // Keep the last state during a temporary connection interruption.
    } finally {
      polling = false;
    }
  }

  Future<void> _leaveAndPop() async {
    if (loading) return;
    if (pid.isNotEmpty && code.isNotEmpty) {
      setState(() => loading = true);
      try {
        await _request('leave');
      } catch (_) {
        // The room expires automatically if the connection is unavailable.
      }
      if (mounted) setState(() => loading = false);
    }
    if (mounted) Navigator.of(context).pop();
  }

  List<Map<String, dynamic>> _teams(Map<String, dynamic> value) {
    final raw = value['teams'];
    if (raw is! List) return const [];
    return raw
        .whereType<Map>()
        .map((item) => Map<String, dynamic>.from(item))
        .toList();
  }

  Map<String, dynamic> _team(Map<String, dynamic> value, String id) {
    for (final item in _teams(value)) {
      if (item['id'] == id) return item;
    }
    return <String, dynamic>{};
  }

  String _teamName(String id) =>
      id == 'blue' ? 'الفريق الأزرق' : 'الفريق الأحمر';
  Color _teamColor(String id) =>
      id == 'blue' ? Colors.blue.shade700 : Colors.red.shade700;

  Widget _button(String text, VoidCallback? onPressed,
      {bool outlined = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: SizedBox(
        width: double.infinity,
        child: outlined
            ? OutlinedButton(
                onPressed: loading ? null : onPressed,
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Text(text, textAlign: TextAlign.center),
                ),
              )
            : FilledButton(
                onPressed: loading ? null : onPressed,
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Text(text, textAlign: TextAlign.center),
                ),
              ),
      ),
    );
  }

  Widget _nameField() => TextField(
        controller: name,
        maxLength: 24,
        textDirection: TextDirection.rtl,
        decoration: const InputDecoration(
          labelText: 'اسم اللاعب',
          border: OutlineInputBorder(),
          counterText: '',
        ),
      );

  Widget _teamSelector() => DropdownButtonFormField<String>(
        value: teamId,
        decoration: const InputDecoration(
          labelText: 'اختر فريقك',
          border: OutlineInputBorder(),
        ),
        items: const [
          DropdownMenuItem(value: 'red', child: Text('الفريق الأحمر')),
          DropdownMenuItem(value: 'blue', child: Text('الفريق الأزرق')),
        ],
        onChanged:
            loading ? null : (value) => setState(() => teamId = value ?? 'red'),
      );

  Widget _setup() => Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Icon(Icons.groups_rounded, size: 70, color: Color(0xFF087F73)),
          const Text(
            'فريق العباقرة',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const Text(
            'نافسوا كفريقين برمز غرفة واحد. اختر الفريق الأحمر أو الأزرق؛ '
            'يسمح لكل فريق من لاعب واحد إلى عشرة لاعبين، ويمكن أن يختلف عدد اللاعبين بين الفريقين. '
            'تُعتمد أول إجابة يرسلها أحد أعضاء كل فريق عن السؤال.',
            textAlign: TextAlign.center,
            style: TextStyle(height: 1.7),
          ),
          const SizedBox(height: 18),
          _nameField(),
          const SizedBox(height: 8),
          _teamSelector(),
          const SizedBox(height: 8),
          DropdownButtonFormField<int>(
            value: rounds,
            decoration: const InputDecoration(
              labelText: 'عدد الأسئلة',
              border: OutlineInputBorder(),
            ),
            items: [5, 10, 15, 20]
                .map((value) => DropdownMenuItem(
                      value: value,
                      child: Text('${_teamArabicDigits(value)} سؤالًا'),
                    ))
                .toList(),
            onChanged: loading
                ? null
                : (value) => setState(() => rounds = value ?? 10),
          ),
          const SizedBox(height: 10),
          DropdownButtonFormField<int>(
            value: seconds,
            decoration: const InputDecoration(
              labelText: 'وقت الإجابة',
              border: OutlineInputBorder(),
            ),
            items: [10, 15, 20, 30]
                .map((value) => DropdownMenuItem(
                      value: value,
                      child: Text('${_teamArabicDigits(value)} ثانية'),
                    ))
                .toList(),
            onChanged: loading
                ? null
                : (value) => setState(() => seconds = value ?? 15),
          ),
          const SizedBox(height: 8),
          _button(
            'أنشئ غرفة فريقية واحصل على رمز',
            () => _action('teamCreate', {
              'name': name.text,
              'teamId': teamId,
              'rounds': rounds,
              'answerSeconds': seconds,
            }),
          ),
          const Divider(height: 32),
          TextField(
            controller: invite,
            maxLength: 6,
            textCapitalization: TextCapitalization.characters,
            textDirection: TextDirection.ltr,
            textAlign: TextAlign.center,
            decoration: const InputDecoration(
              labelText: 'رمز الغرفة المشتركة',
              hintText: 'مثال: HX7K2P',
              border: OutlineInputBorder(),
              counterText: '',
            ),
          ),
          _button(
            'انضم إلى الغرفة بالفريق المختار',
            () => _action('teamJoin', {
              'name': name.text,
              'teamId': teamId,
              'code': invite.text.trim().toUpperCase(),
            }),
            outlined: true,
          ),
          const SizedBox(height: 10),
          ExpansionTile(
            title: const Text('إعدادات الخادم'),
            children: [
              const Padding(
                padding: EdgeInsets.all(8),
                child: Text(
                  'اترك العنوان الافتراضي كما هو. لا تغيّره إلا إذا نُقل الخادم إلى عنوان آخر.',
                  textAlign: TextAlign.right,
                ),
              ),
              TextField(
                controller: server,
                textDirection: TextDirection.ltr,
                decoration: const InputDecoration(
                  labelText: 'عنوان الخادم HTTPS',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
        ],
      );

  Widget _room(Map<String, dynamic> value) {
    final you = Map<String, dynamic>.from(value['you'] as Map? ?? const {});
    if (value['phase'] == 'lobby') return _lobby(value, you);
    if (value['phase'] == 'finished') return _finished(value, you);
    return _game(value, you);
  }

  Widget _lobby(Map<String, dynamic> value, Map<String, dynamic> you) {
    final teams = _teams(value);
    final red = _team(value, 'red');
    final blue = _team(value, 'blue');
    final redCount = (red['players'] as List? ?? const []).length;
    final blueCount = (blue['players'] as List? ?? const []).length;
    final canStart = redCount > 0 && blueCount > 0;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Icon(Icons.groups_rounded, size: 64, color: Color(0xFF087F73)),
        const Text(
          'غرفة فريق العباقرة',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        const Text('رمز واحد يشاركه لاعبو الفريقين',
            textAlign: TextAlign.center),
        SelectableText(
          code,
          textAlign: TextAlign.center,
          textDirection: TextDirection.ltr,
          style: const TextStyle(
            fontSize: 42,
            fontWeight: FontWeight.w900,
            letterSpacing: 5,
            color: Color(0xFF087F73),
          ),
        ),
        _button('نسخ رمز الغرفة', () async {
          await Clipboard.setData(ClipboardData(text: code));
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('نُسخ رمز الغرفة')),
            );
          }
        }, outlined: true),
        const SizedBox(height: 8),
        Text(
          'أنت: ${you['name']} — ${_teamName(you['teamId']?.toString() ?? 'red')}',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 12),
        ...teams.map(_teamLobbyCard),
        if (!canStart)
          const Padding(
            padding: EdgeInsets.all(8),
            child: Text(
              'يلزم وجود لاعب واحد على الأقل في كل فريق قبل بدء المنافسة.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.blueGrey, height: 1.5),
            ),
          ),
        if (you['isHost'] == true)
          _button(
            'ابدأ منافسة الفريقين',
            canStart ? () => _action('teamStart') : null,
          )
        else
          const Text(
            'بانتظار منشئ الغرفة ليبدأ المنافسة…',
            textAlign: TextAlign.center,
          ),
        _button('مغادرة الغرفة', _leaveAndPop, outlined: true),
      ],
    );
  }

  Widget _teamLobbyCard(Map<String, dynamic> team) {
    final id = team['id']?.toString() ?? 'red';
    final members = (team['players'] as List? ?? const [])
        .whereType<Map>()
        .map((player) => Map<String, dynamic>.from(player))
        .toList();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Icon(Icons.shield_rounded, color: _teamColor(id)),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    '${team['name']} (${_teamArabicDigits(members.length)}/١٠)',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: _teamColor(id),
                    ),
                  ),
                ),
              ],
            ),
            if (members.isEmpty)
              const Padding(
                padding: EdgeInsets.only(top: 8),
                child: Text('بانتظار أول لاعب…', textAlign: TextAlign.right),
              )
            else
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: members.map((player) {
                    return Chip(
                      avatar: Icon(
                        player['isHost'] == true
                            ? Icons.star_rounded
                            : Icons.person,
                        size: 18,
                      ),
                      label: Text(player['name']?.toString() ?? 'لاعب'),
                    );
                  }).toList(),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _teamScoreCard(Map<String, dynamic> team) {
    final id = team['id']?.toString() ?? 'red';
    final members = team['players'] as List? ?? const [];
    return Expanded(
      child: Card(
        color: id == 'blue' ? Colors.blue.shade50 : Colors.red.shade50,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
          child: Column(
            children: [
              Icon(Icons.shield_rounded, color: _teamColor(id)),
              const SizedBox(height: 3),
              Text(
                team['name']?.toString() ?? _teamName(id),
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: _teamColor(id),
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                '${members.length} لاعب',
                style: const TextStyle(fontSize: 12, color: Colors.blueGrey),
              ),
              Text(
                _teamArabicDigits((team['score'] as num?)?.toInt() ?? 0),
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.w900,
                  color: _teamColor(id),
                ),
              ),
              if (team['answered'] == true)
                Text(
                  'أجاب ${team['answerName'] ?? 'عضو الفريق'}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 11),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _timer(Map<String, dynamic> value) {
    final remainingMs = (value['remainingMs'] as num?)?.toInt() ?? 0;
    final totalMs = (value['timerTotalMs'] as num?)?.toDouble() ?? 1;
    final secondsLeft = remainingMs <= 0 ? 0 : (remainingMs + 999) ~/ 1000;
    final sub = value['sub']?.toString() ?? '';
    final threshold = sub == 'answering'
        ? 5000
        : sub == 'reading'
            ? 2000
            : 0;
    final urgent = threshold > 0 && remainingMs > 0 && remainingMs <= threshold;
    final color = urgent ? Colors.red.shade700 : Colors.teal.shade800;
    final progress =
        totalMs <= 0 ? 0.0 : (remainingMs / totalMs).clamp(0.0, 1.0).toDouble();
    final label = sub == 'reading'
        ? 'وقت قراءة السؤال'
        : sub == 'answering'
            ? 'وقت إجابة الفريقين'
            : 'تظهر النتيجة التالية خلال';
    return Column(
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
          decoration: BoxDecoration(
            color: urgent ? Colors.red.shade50 : Colors.teal.shade50,
            border: Border.all(color: color, width: urgent ? 2.5 : 1.5),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            children: [
              Text(label,
                  style: TextStyle(color: color, fontWeight: FontWeight.bold)),
              Text(
                '${_teamArabicDigits(secondsLeft)} ثانية',
                style: TextStyle(
                    fontSize: 42,
                    height: 1.2,
                    color: color,
                    fontWeight: FontWeight.w900),
              ),
              if (urgent)
                Text('أسرعوا! الوقت يوشك على الانتهاء',
                    style: TextStyle(color: Colors.red.shade800)),
            ],
          ),
        ),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: LinearProgressIndicator(
            value: progress,
            minHeight: 10,
            color: color,
            backgroundColor: color.withOpacity(0.16),
          ),
        ),
      ],
    );
  }

  Widget _game(Map<String, dynamic> value, Map<String, dynamic> you) {
    final teamList = _teams(value);
    final red = _team(value, 'red');
    final blue = _team(value, 'blue');
    final myTeam = _team(value, you['teamId']?.toString() ?? 'red');
    final myTeamAnswered = myTeam['answered'] == true;
    final question = value['question'] as Map<String, dynamic>?;
    final sub = value['sub']?.toString() ?? '';
    final reveal = sub == 'reveal';
    final round = (value['round'] as num?)?.toInt() ?? 0;
    final correctIndex = (question?['correctIndex'] as num?)?.toInt();
    final options = (question?['options'] as List?) ?? const [];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            _teamScoreCard(red),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 2),
              child: Text('VS', style: TextStyle(fontWeight: FontWeight.w900)),
            ),
            _teamScoreCard(blue),
          ],
        ),
        Text(
          'السؤال ${_teamArabicDigits(round)} من ${_teamArabicDigits((value['total'] as num?)?.toInt() ?? 0)}',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 6),
        Text(
          value['status']?.toString() ?? '',
          textAlign: TextAlign.center,
          style: const TextStyle(
              color: Color(0xFF087F73),
              fontWeight: FontWeight.bold,
              height: 1.5),
        ),
        _timer(value),
        if (sub == 'reading')
          _button('ابدأ وقت الإجابة للجميع', () => _action('teamBegin'),
              outlined: true),
        const SizedBox(height: 10),
        if (question != null) ...[
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    question['text']?.toString() ?? '',
                    style: const TextStyle(
                        fontSize: 22, fontWeight: FontWeight.bold, height: 1.7),
                  ),
                  const SizedBox(height: 12),
                  ...List.generate(options.length, (index) {
                    final answer = myTeam['answer'] as Map?;
                    final myWrong = reveal &&
                        answer != null &&
                        (answer['option'] as num?)?.toInt() == index &&
                        answer['correct'] != true;
                    final isCorrect = reveal && correctIndex == index;
                    final enabled = sub == 'answering' && !myTeamAnswered;
                    final background = myWrong
                        ? Colors.red.shade100
                        : isCorrect
                            ? Colors.green.shade100
                            : null;
                    final border = myWrong
                        ? Colors.red.shade700
                        : isCorrect
                            ? Colors.green.shade700
                            : Colors.teal.shade200;
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: OutlinedButton(
                        onPressed: enabled && !loading
                            ? () => _action('teamAnswer', {
                                  'option': index,
                                  'qi': round - 1,
                                })
                            : null,
                        style: OutlinedButton.styleFrom(
                          backgroundColor: background,
                          side: BorderSide(
                              color: border,
                              width: isCorrect || myWrong ? 2 : 1),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 13),
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(
                                '${[
                                  'أ',
                                  'ب',
                                  'ج',
                                  'د'
                                ][index]}) ${options[index]}',
                                textAlign: TextAlign.right,
                                style: TextStyle(
                                  color: myWrong
                                      ? Colors.red.shade900
                                      : isCorrect
                                          ? Colors.green.shade900
                                          : null,
                                  fontSize: 17,
                                  fontWeight: isCorrect || myWrong
                                      ? FontWeight.bold
                                      : null,
                                ),
                              ),
                            ),
                            if (myWrong)
                              Icon(Icons.close_rounded,
                                  color: Colors.red.shade800, size: 28),
                            if (isCorrect)
                              Icon(Icons.check_circle_rounded,
                                  color: Colors.green.shade800, size: 26),
                          ],
                        ),
                      ),
                    );
                  }),
                  if (myTeamAnswered && !reveal)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(
                        'أرسل ${myTeam['answerName'] ?? 'أحد أعضاء فريقك'} إجابة الفريق؛ '
                        'لن تُقبل إجابة أخرى من الفريق نفسه لهذا السؤال.',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color:
                                _teamColor(you['teamId']?.toString() ?? 'red')),
                      ),
                    ),
                  if (reveal && question['explanation'] != null)
                    Card(
                      color: Colors.teal.shade50,
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Text(
                          '💡 ${question['explanation']}',
                          style: const TextStyle(height: 1.6),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ] else
          const Padding(
            padding: EdgeInsets.all(22),
            child: Text('جارٍ تحميل السؤال…', textAlign: TextAlign.center),
          ),
        if (reveal)
          ...teamList.map((team) {
            final answer = team['answer'] as Map?;
            final message = answer == null
                ? '${team['name']}: لم يرسل الفريق إجابة.'
                : '${team['name']}: ${answer['name']} — '
                    '${answer['correct'] == true ? 'إجابة صحيحة (+${answer['points']} نقطة)' : 'إجابة خاطئة (دون نقاط)'}';
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Text(
                message,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: answer == null
                      ? Colors.blueGrey
                      : answer['correct'] == true
                          ? Colors.green.shade800
                          : Colors.red.shade800,
                  fontWeight: FontWeight.w600,
                ),
              ),
            );
          }),
      ],
    );
  }

  Widget _finished(Map<String, dynamic> value, Map<String, dynamic> you) {
    final winner =
        Map<String, dynamic>.from(value['winner'] as Map? ?? const {});
    final tie = winner['tie'] == true;
    final myTeamId = you['teamId']?.toString() ?? 'red';
    final myTeamWon = winner['teamId'] == myTeamId;
    final red = _team(value, 'red');
    final blue = _team(value, 'blue');
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Icon(Icons.emoji_events_rounded, size: 88, color: Colors.amber),
        Text(
          tie
              ? 'تعادل فريقا العباقرة!'
              : 'الفائز: ${winner['name'] ?? 'الفريق'}',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),
        Row(children: [_teamScoreCard(red), _teamScoreCard(blue)]),
        const SizedBox(height: 12),
        Text(
          tie
              ? '${you['name']} — تعادلت مع ${_teamName(myTeamId)}'
              : myTeamWon
                  ? 'مبروك يا ${you['name']}! فزتم مع ${_teamName(myTeamId)}'
                  : '${you['name']} شارك مع ${_teamName(myTeamId)}',
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 18),
        _button('العودة إلى أنماط اللعب', _leaveAndPop),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final current = state;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('👥 فريق العباقرة'),
          leading: IconButton(
            tooltip: 'رجوع ومغادرة الغرفة',
            icon: const Icon(Icons.arrow_back_rounded),
            onPressed: _leaveAndPop,
          ),
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                if (error.isNotEmpty)
                  Container(
                    padding: const EdgeInsets.all(12),
                    margin: const EdgeInsets.only(bottom: 10),
                    decoration: BoxDecoration(
                      color: Colors.red.shade50,
                      border: Border.all(color: Colors.red.shade300),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(error,
                        style: TextStyle(color: Colors.red.shade900)),
                  ),
                if (loading) const LinearProgressIndicator(),
                if (current == null) _setup() else _room(current),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
