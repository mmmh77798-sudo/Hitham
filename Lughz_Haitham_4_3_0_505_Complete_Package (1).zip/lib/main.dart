import 'dart:math';

import 'package:flutter/material.dart';

import 'questions.dart';
import 'duel.dart';

void main() => runApp(const HithamApp());

String arNum(int n) {
  const digits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  return n.toString().split('').map((c) => digits[int.parse(c)]).join();
}

const optionLetters = ['أ', 'ب', 'ج', 'د'];

class HithamApp extends StatelessWidget {
  const HithamApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'لغز هيثم',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF087F73)),
        scaffoldBackgroundColor: const Color(0xFFF3F8F7),
      ),
      home: const QuizPage(),
    );
  }
}

class QuizPage extends StatefulWidget {
  const QuizPage({super.key});

  @override
  State<QuizPage> createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  final rng = Random();
  final solvedLevels = <int>{};
  final hidden = <int>{};

  int level = 0;
  int score = 0;
  int right = 0;
  int wrong = 0;
  int chosen = -1;
  bool answered = false;
  bool hintUsed = false;
  bool finished = false;
  bool showLevels = false;

  Question get q => questions[level];

  @override
  void initState() {
    super.initState();
    loadLevel(0);
  }

  void loadLevel(int i) {
    setState(() {
      level = i.clamp(0, questions.length - 1);
      chosen = -1;
      answered = false;
      hintUsed = false;
      finished = false;
      showLevels = false;
      hidden.clear();
    });
  }

  void notify(String text, bool good) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text, textDirection: TextDirection.rtl),
        behavior: SnackBarBehavior.floating,
        backgroundColor: good ? Colors.green.shade700 : Colors.red.shade700,
      ),
    );
  }

  void answer(int i) {
    if (answered) return;
    final correct = i == q.answerIndex;
    setState(() {
      chosen = i;
      answered = true;
      if (correct) {
        score += 10;
        right++;
        solvedLevels.add(level);
      } else {
        score = max(0, score - 2);
        wrong++;
      }
    });
    if (correct) {
      notify('إجابة صحيحة! +١٠ نقاط', true);
    } else {
      notify(
          'خاطئ −٢ · الصحيح: ${optionLetters[q.answerIndex]}) ${q.options[q.answerIndex]}',
          false);
    }
  }

  void hint() {
    if (answered || hintUsed) return;
    if (score < 2) {
      notify('تحتاج إلى نقطتين على الأقل لكشف التلميح.', false);
      return;
    }
    final bad = <int>[];
    for (var i = 0; i < q.options.length; i++) {
      if (i != q.answerIndex) bad.add(i);
    }
    bad.shuffle(rng);
    setState(() {
      score -= 2;
      hintUsed = true;
      hidden.clear();
      hidden.addAll(bad.take(2));
    });
    notify('حُذف خياران خاطئان −٢ نقطة', true);
  }

  void nextLevel() {
    if (level == questions.length - 1) {
      setState(() => finished = true);
      return;
    }
    loadLevel(level + 1);
  }

  void previousLevel() {
    if (level == 0) {
      notify('أنت في المرحلة الأولى بالفعل.', false);
      return;
    }
    loadLevel(level - 1);
  }

  void restart() {
    setState(() {
      level = 0;
      score = 0;
      right = 0;
      wrong = 0;
      solvedLevels.clear();
      finished = false;
    });
    loadLevel(0);
  }

  void about() {
    showAboutDialog(
      context: context,
      applicationName: 'لغز هيثم',
      applicationVersion: '٤٫٣٫٠ — ${arNum(questions.length)} سؤال',
      applicationLegalese:
          'أسئلة معلومات عامة صعبة باختيارات متعددة، مع شرح المعلومة بعد كل إجابة.',
      children: const [
        Directionality(
          textDirection: TextDirection.rtl,
          child: Text('اختر الإجابة الصحيحة من أربعة خيارات في كل مرحلة.'),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: showLevels ? levelsAppBar() : gameAppBar(),
        body: SafeArea(
          child: showLevels
              ? levelsScreen()
              : (finished ? resultScreen() : gameScreen()),
        ),
      ),
    );
  }

  PreferredSizeWidget gameAppBar() {
    return AppBar(
      title: const Text('ألغاز هيثم'),
      centerTitle: true,
      actions: [
        IconButton(
            tooltip: 'قسم العباقرة',
            icon: const Icon(Icons.emoji_events),
            onPressed: () => Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => const DuelPage()))),
        IconButton(
          tooltip: 'كل المراحل',
          icon: const Icon(Icons.grid_view_rounded),
          onPressed: () => setState(() => showLevels = true),
        ),
        IconButton(
          tooltip: 'عن اللعبة',
          icon: const Icon(Icons.info_outline),
          onPressed: about,
        ),
      ],
    );
  }

  PreferredSizeWidget levelsAppBar() {
    return AppBar(
      title: Text('اختر مرحلة من ${arNum(questions.length)}'),
      centerTitle: true,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios_new_rounded),
        onPressed: () => setState(() => showLevels = false),
      ),
    );
  }

  Widget gameScreen() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          FilledButton.icon(
              onPressed: () => Navigator.of(context)
                  .push(MaterialPageRoute(builder: (_) => const DuelPage())),
              icon: const Icon(Icons.emoji_events),
              label: const Text('قسم العباقرة — تحدَّ منافسك بكود')),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Chip(
                  label: Text(
                      'المرحلة ${arNum(level + 1)} من ${arNum(questions.length)}')),
              Chip(label: Text('النقاط: ${arNum(score)}')),
            ],
          ),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: (level + 1) / questions.length,
              minHeight: 8,
              backgroundColor: Colors.teal.shade100,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                q.chapter,
                style: TextStyle(
                  color: Colors.teal.shade800,
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
                decoration: BoxDecoration(
                  color: Colors.amber.shade100,
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(q.difficulty, style: const TextStyle(fontSize: 12)),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: const [
                      Icon(Icons.help_outline_rounded,
                          color: Color(0xFF087F73)),
                      SizedBox(width: 8),
                      Text('سؤال',
                          style: TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    q.text,
                    style: const TextStyle(
                        fontSize: 21, height: 1.7, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 18),
                  ...List.generate(q.options.length, (i) {
                    if (hidden.contains(i)) return const SizedBox.shrink();
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: optionButton(i),
                    );
                  }),
                  if (answered) ...[
                    const SizedBox(height: 6),
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: const Color(0xFFEFF9F7),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: Colors.teal.shade200),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          const Text(
                            '💡 المعلومة',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF087F73)),
                          ),
                          const SizedBox(height: 6),
                          Text(q.explanation,
                              style:
                                  const TextStyle(fontSize: 16, height: 1.7)),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: answered || hintUsed ? null : hint,
                  icon: const Icon(Icons.tips_and_updates_outlined, size: 18),
                  label: const Text('تلميح', style: TextStyle(fontSize: 13)),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: previousLevel,
                  icon: const Icon(Icons.arrow_forward_ios_rounded, size: 16),
                  label: const Text('السابق', style: TextStyle(fontSize: 13)),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: TextButton.icon(
                  onPressed: () => setState(() => showLevels = true),
                  icon: const Icon(Icons.grid_view_rounded, size: 16),
                  label: const Text('كل المراحل'),
                ),
              ),
              Expanded(
                child: Text(
                  'صحيح ${arNum(right)} · خاطئ ${arNum(wrong)}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 13),
                ),
              ),
            ],
          ),
          if (answered) ...[
            const SizedBox(height: 10),
            FilledButton(
              onPressed: nextLevel,
              child: Text(level == questions.length - 1
                  ? 'عرض النتيجة'
                  : 'المرحلة التالية'),
            ),
          ],
        ],
      ),
    );
  }

  Widget optionButton(int i) {
    Color bg = Colors.white;
    Color border = Colors.teal.shade100;
    Color fg = const Color(0xFF123330);
    Color badgeBg = const Color(0xFFE8F4F2);
    Color badgeFg = const Color(0xFF087F73);
    if (answered) {
      if (i == q.answerIndex) {
        bg = const Color(0xFFE9F7ED);
        border = const Color(0xFF7BC47F);
        badgeBg = const Color(0xFF188038);
        badgeFg = Colors.white;
      } else if (i == chosen) {
        bg = const Color(0xFFFDECEB);
        border = const Color(0xFFE57373);
        badgeBg = const Color(0xFFB3261E);
        badgeFg = Colors.white;
      } else {
        bg = Colors.grey.shade50;
        fg = Colors.grey.shade500;
        badgeBg = Colors.grey.shade200;
        badgeFg = Colors.grey.shade600;
      }
    }
    return SizedBox(
      width: double.infinity,
      child: OutlinedButton(
        onPressed: answered ? null : () => answer(i),
        style: OutlinedButton.styleFrom(
          backgroundColor: bg,
          foregroundColor: fg,
          side: BorderSide(color: border, width: 1.4),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
        child: Row(
          children: [
            Container(
              width: 32,
              height: 32,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                  color: badgeBg, borderRadius: BorderRadius.circular(9)),
              child: Text(
                optionLetters[i],
                style: TextStyle(fontWeight: FontWeight.bold, color: badgeFg),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                q.options[i],
                style: const TextStyle(fontSize: 16, height: 1.5),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget levelsScreen() {
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 1,
      ),
      itemCount: questions.length,
      itemBuilder: (context, i) {
        final isCurrent = i == level;
        final isSolved = solvedLevels.contains(i);
        return InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: () => loadLevel(i),
          child: Container(
            decoration: BoxDecoration(
              color: isCurrent
                  ? const Color(0xFF087F73)
                  : (isSolved ? Colors.green.shade50 : Colors.white),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: isCurrent
                    ? const Color(0xFF087F73)
                    : (isSolved ? Colors.green.shade300 : Colors.teal.shade100),
              ),
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                Text(
                  arNum(i + 1),
                  style: TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.bold,
                    color: isCurrent ? Colors.white : Colors.teal.shade900,
                  ),
                ),
                if (isSolved)
                  Positioned(
                    top: 4,
                    left: 4,
                    child: Icon(Icons.check_circle,
                        size: 14, color: Colors.green.shade600),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget resultScreen() {
    final total = right + wrong;
    final pct = total == 0 ? 0 : (right * 100 / total).round();
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.emoji_events, size: 72, color: Colors.amber),
                const SizedBox(height: 12),
                const Text('أحسنت!',
                    style:
                        TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('أكملت ${arNum(questions.length)} سؤالًا',
                    style: const TextStyle(fontSize: 18)),
                const SizedBox(height: 6),
                Text('النقاط: ${arNum(score)} نقطة',
                    style: const TextStyle(fontSize: 20)),
                const SizedBox(height: 6),
                Text(
                    'صحيح ${arNum(right)} · خاطئ ${arNum(wrong)} · النسبة ${arNum(pct)}٪',
                    style: const TextStyle(fontSize: 16)),
                const SizedBox(height: 20),
                FilledButton.icon(
                  onPressed: restart,
                  icon: const Icon(Icons.restart_alt),
                  label: const Text('العب مرة أخرى'),
                ),
                const SizedBox(height: 10),
                OutlinedButton.icon(
                  onPressed: () => setState(() => showLevels = true),
                  icon: const Icon(Icons.grid_view_rounded),
                  label: const Text('اختر مرحلة'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
