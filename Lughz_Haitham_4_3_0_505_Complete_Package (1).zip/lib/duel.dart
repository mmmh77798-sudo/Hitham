import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'team_duel.dart';

String _arabicDigits(int value) {
  const digits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  return value.toString().split('').map((c) => digits[int.parse(c)]).join();
}

String _latestEvent(Map<String, dynamic> value) {
  final events = value['events'];
  if (events is! List || events.isEmpty) return '';
  return events.last.toString();
}

bool _isWrongEvent(String text) =>
    text.contains('إجابة خاطئة') ||
    text.contains('انتهى الوقت') ||
    text.contains('أخفق المنافسان');

class DuelPage extends StatefulWidget {
  const DuelPage({super.key});

  @override
  State<DuelPage> createState() => _DuelPageState();
}

class _DuelPageState extends State<DuelPage> {
  static const MethodChannel _audio = MethodChannel('lughz_haitham/audio');

  final name = TextEditingController();
  final invite = TextEditingController();
  final server = TextEditingController(
    text: 'https://hitham.hithamadal.workers.dev',
  );
  final client = HttpClient()..userAgent = 'LughzHaitham/4.3.0 (Android)';

  String code = '', pid = '', token = '', error = '';
  Map<String, dynamic>? state;
  Timer? timer;
  bool loading = false, polling = false;
  int rounds = 10, seconds = 15;
  int? _lastCountdownSecond;
  int? _wrongOption, _wrongRound;
  String _lastEventKey = '', _lastFinishKey = '';

  @override
  void initState() {
    super.initState();
    timer = Timer.periodic(const Duration(milliseconds: 700), (_) => poll());
  }

  @override
  void dispose() {
    timer?.cancel();
    client.close(force: true);
    name.dispose();
    invite.dispose();
    server.dispose();
    super.dispose();
  }

  Future<void> _audioCall(String method, Map<String, dynamic> arguments) async {
    try {
      await _audio.invokeMethod<void>(method, arguments);
    } catch (_) {
      // Audio/TTS must never interrupt the match if the device lacks a service.
    }
  }

  void _playSound(String type) {
    unawaited(_audioCall('play', {'type': type}));
  }

  Future<void> _announceAfterWinCue(String text) async {
    await Future<void>.delayed(const Duration(milliseconds: 720));
    await _audioCall('speak', {'text': text});
  }

  void _handleIncomingState(Map<String, dynamic> value) {
    if (value['phase'] != 'finished') _lastFinishKey = '';
    final round = (value['round'] as num?)?.toInt() ?? 0;
    final event = _latestEvent(value);
    final eventKey = '$round|$event';
    if (event.isNotEmpty && eventKey != _lastEventKey) {
      _lastEventKey = eventKey;
      if (_isWrongEvent(event)) _playSound('wrong');
    }

    if (value['phase'] == 'playing' && value['sub'] == 'answering') {
      final remainingMs = (value['remainingMs'] as num?)?.toInt() ?? 0;
      final remainingSeconds =
          remainingMs <= 0 ? 0 : (remainingMs + 999) ~/ 1000;
      if (remainingSeconds > 5) {
        _lastCountdownSecond = remainingSeconds;
      } else if (remainingSeconds > 0 &&
          remainingSeconds != _lastCountdownSecond) {
        _lastCountdownSecond = remainingSeconds;
        _playSound('tick');
      }
    } else {
      _lastCountdownSecond = null;
    }

    if (value['phase'] == 'finished') {
      final winner = value['winner'] as Map? ?? const {};
      final finishKey =
          '${value['code']}|${winner['id']}|${winner['name']}|${winner['score']}|${winner['tie']}';
      if (finishKey != _lastFinishKey) {
        _lastFinishKey = finishKey;
        _playSound('win');
        final players = value['players'] as List? ?? const [];
        final names = players
            .map((p) => (p as Map)['name']?.toString() ?? 'لاعب')
            .join(' و ');
        final announcement = winner['tie'] == true
            ? 'انتهت المنافسة بالتعادل بين $names'
            : 'انتهت المنافسة. الفائز هو ${winner['name'] ?? 'اللاعب الفائز'}';
        unawaited(_announceAfterWinCue(announcement));
      }
    }
  }

  Future<Map<String, dynamic>> request(
    String path, [
    Map<String, dynamic> extra = const {},
  ]) async {
    final base = server.text.trim().replaceAll(RegExp(r'/+$'), '');
    final req = await client
        .postUrl(Uri.parse('$base/api/$path'))
        .timeout(const Duration(seconds: 12));
    req.headers.contentType = ContentType.json;
    req.write(jsonEncode({'code': code, 'pid': pid, 'token': token, ...extra}));
    final res = await req.close().timeout(const Duration(seconds: 12));
    return jsonDecode(await utf8.decoder.bind(res).join())
        as Map<String, dynamic>;
  }

  Future<void> action(String path,
      [Map<String, dynamic> extra = const {}]) async {
    if (loading) return;
    setState(() {
      loading = true;
      error = '';
    });
    try {
      final result = await request(path, extra);
      if (!mounted) return;
      if (result['ok'] != true) {
        setState(() => error = result['error'] ?? 'حدث خطأ');
      } else {
        int? wrongOptionToMark;
        int? wrongRoundToMark;
        if (path == 'answer') {
          final event = _latestEvent(result);
          final you = result['you'] as Map? ?? const {};
          final myName = you['name']?.toString() ?? '';
          if (_isWrongEvent(event) &&
              (myName.isEmpty || event.contains(myName))) {
            wrongOptionToMark = (extra['option'] as num?)?.toInt();
            wrongRoundToMark = (result['round'] as num?)?.toInt();
          }
        }
        _handleIncomingState(result);
        setState(() {
          code = result['code'] ?? code;
          pid = result['pid'] ?? pid;
          token = result['token'] ?? token;
          if (wrongOptionToMark != null && wrongRoundToMark != null) {
            _wrongOption = wrongOptionToMark;
            _wrongRound = wrongRoundToMark;
          }
          state = result;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() => error = 'تعذر الاتصال. تحقق من الإنترنت وعنوان الخادم.');
      }
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _newOpponent() async {
    if (loading) return;
    setState(() => loading = true);
    if (code.isNotEmpty && pid.isNotEmpty) {
      try {
        await request('leave');
      } catch (_) {
        // A fresh room can still be created if the old connection has expired.
      }
    }
    if (!mounted) return;
    setState(() {
      state = null;
      pid = '';
      token = '';
      code = '';
      invite.clear();
      _wrongOption = null;
      _wrongRound = null;
      _lastCountdownSecond = null;
      _lastEventKey = '';
      _lastFinishKey = '';
      loading = false;
    });
  }

  Future<void> poll() async {
    if (pid.isEmpty || polling || loading) return;
    polling = true;
    try {
      final result = await request('state');
      if (mounted && result['ok'] == true) {
        _handleIncomingState(result);
        setState(() => state = result);
      }
    } catch (_) {
      // Keep the last displayed state during a brief connection interruption.
    } finally {
      polling = false;
    }
  }

  Widget btn(String title, VoidCallback? fn) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: FilledButton(
          onPressed: loading ? null : fn,
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Text(title),
          ),
        ),
      );

  Widget field(TextEditingController controller, String label,
          {bool latin = false}) =>
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: TextField(
          controller: controller,
          textDirection: latin ? TextDirection.ltr : TextDirection.rtl,
          decoration: InputDecoration(
            labelText: label,
            border: const OutlineInputBorder(),
          ),
        ),
      );

  Widget _feedbackBanner(String text, {required bool isCorrect}) => Container(
        margin: const EdgeInsets.symmetric(vertical: 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: isCorrect ? Colors.green.shade50 : Colors.red.shade50,
          border: Border.all(
            color: isCorrect ? Colors.green.shade700 : Colors.red.shade700,
            width: 2,
          ),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          children: [
            Icon(
              isCorrect ? Icons.check_circle_rounded : Icons.cancel_rounded,
              color: isCorrect ? Colors.green.shade800 : Colors.red.shade800,
              size: 34,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                text,
                textAlign: TextAlign.right,
                style: TextStyle(
                  color:
                      isCorrect ? Colors.green.shade900 : Colors.red.shade900,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  height: 1.45,
                ),
              ),
            ),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    final current = state;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('🏆 قسم العباقرة')),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              if (error.isNotEmpty)
                Text(error, style: const TextStyle(color: Colors.red)),
              if (loading) const LinearProgressIndicator(),
              if (current == null) ...setup() else ...room(current),
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> setup() => [
        const Text(
          'تحدَّ منافسك من هاتف آخر',
          style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        Card(
          color: Colors.teal.shade50,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                  'تحدٍ جماعي بدل المواجهة الفردية',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
                ),
                const SizedBox(height: 4),
                const Text(
                  'كوّن فريقين حتى ١٠ لاعبين لكل فريق، برمز غرفة واحد.',
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 6),
                FilledButton.icon(
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const TeamDuelPage()),
                  ),
                  icon: const Icon(Icons.groups_rounded),
                  label: const Text('افتح قسم فريق العباقرة'),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        const Text(
          'النمط الفردي: أنشئ غرفة وأرسل الكود لمنافسك. السؤال يظهر لصاحب الدور فقط. '
          'لديك ٥ ثوانٍ للقراءة ثم يبدأ مؤقت الإجابة تلقائيًا، أو اضغط '
          '«قرأت السؤال». الخطأ أو انتهاء الوقت يعيد السؤال للمنافس بوقت كامل.',
          style: TextStyle(height: 1.8),
        ),
        field(name, 'اسمك'),
        DropdownButtonFormField<int>(
          value: rounds,
          decoration: const InputDecoration(labelText: 'عدد الأسئلة'),
          items: [5, 10, 15, 20]
              .map((n) => DropdownMenuItem(value: n, child: Text('$n سؤالًا')))
              .toList(),
          onChanged: (n) => setState(() => rounds = n!),
        ),
        DropdownButtonFormField<int>(
          value: seconds,
          decoration: const InputDecoration(labelText: 'وقت الإجابة'),
          items: [10, 15, 20, 30]
              .map((n) => DropdownMenuItem(value: n, child: Text('$n ثانية')))
              .toList(),
          onChanged: (n) => setState(() => seconds = n!),
        ),
        btn(
          'أنشئ منافسة واحصل على كود',
          () => action('create', {
            'name': name.text,
            'rounds': rounds,
            'answerSeconds': seconds,
          }),
        ),
        const Divider(),
        field(invite, 'كود دعوة المنافس', latin: true),
        btn(
          'انضم بالكود',
          () => action('join', {
            'name': name.text,
            'code': invite.text.trim().toUpperCase(),
          }),
        ),
        ExpansionTile(
          title: const Text('إعدادات الخادم'),
          children: [
            const Text(
              'الخادم الدائم مضبوط تلقائيًا. اترك العنوان كما هو للاتصال '
              'بمنافسات العباقرة؛ لا تغيّره إلا إذا تغيّر رابط الاستضافة.',
            ),
            field(server, 'عنوان HTTPS للخادم', latin: true),
          ],
        ),
      ];

  List<Widget> room(Map<String, dynamic> value) {
    final you = value['you'] as Map<String, dynamic>;
    final opponent = value['opponent'] as Map<String, dynamic>?;

    if (value['phase'] == 'lobby') {
      return [
        const Text('كود الدعوة', textAlign: TextAlign.center),
        SelectableText(
          code,
          textAlign: TextAlign.center,
          textDirection: TextDirection.ltr,
          style: const TextStyle(
            fontSize: 42,
            fontWeight: FontWeight.bold,
            letterSpacing: 5,
            color: Colors.teal,
          ),
        ),
        btn('نسخ الكود لإرساله للمنافس',
            () => Clipboard.setData(ClipboardData(text: code))),
        Text(
          'أنت: ${you['name']}\nالمنافس: ${opponent?['name'] ?? 'بانتظار الدخول…'}',
          style: const TextStyle(fontSize: 20, height: 2),
        ),
        if (you['isHost'] == true)
          btn('ابدأ المنافسة', opponent == null ? null : () => action('start'))
        else
          const Text('بانتظار أن يبدأ صاحب الغرفة…'),
      ];
    }

    if (value['phase'] == 'finished') {
      final winner = value['winner'] as Map? ?? const {};
      final tie = winner['tie'] == true;
      final winnerName = winner['name']?.toString() ?? 'الفائز';
      final opponentName = opponent?['name']?.toString() ?? 'المنافس';
      final resultTitle = tie
          ? 'تعادل بين ${you['name']} و$opponentName'
          : winner['id'] == you['id']
              ? 'مبروك يا $winnerName! أنت الفائز'
              : 'الفائز في المنافسة: $winnerName';
      final youRequested = value['youRequestedRematch'] == true;
      final opponentRequested = value['opponentRequestedRematch'] == true;
      final rematchLabel = youRequested
          ? 'طلبت المتابعة — بانتظار المنافس'
          : opponentRequested
              ? 'موافقة وإعادة اللعب مع نفس المنافس'
              : 'متابعة مع نفس المنافس';
      final rematchHint = youRequested
          ? 'سيبدأ اللعب تلقائيًا عندما يوافق منافسك.'
          : opponentRequested
              ? '$opponentName يريد متابعة اللعب معك.'
              : 'اضغطا «متابعة» للعب مرة أخرى دون إعادة إرسال كود الدعوة.';
      return [
        const Icon(Icons.emoji_events, size: 90, color: Colors.amber),
        Text(
          resultTitle,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 27, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),
        if (!tie)
          Text(
            'اسم الفائز: $winnerName',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 22,
              color: Colors.teal.shade800,
              fontWeight: FontWeight.w700,
            ),
          ),
        Text(
          '${you['name']}: ${you['score']} نقطة\n'
          '$opponentName: ${opponent?['score'] ?? 0} نقطة',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 22, height: 2),
        ),
        const SizedBox(height: 8),
        Text(
          rematchHint,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 16, height: 1.5),
        ),
        btn(rematchLabel, youRequested ? null : () => action('rematch')),
        btn('منافس جديد', _newOpponent),
      ];
    }

    final question = value['question'] as Map<String, dynamic>?;
    final remainingMs = (value['remainingMs'] as num?)?.toInt() ?? 0;
    final totalMs = (value['timerTotalMs'] as num?)?.toDouble() ?? 1.0;
    final secondsLeft = remainingMs <= 0 ? 0 : (remainingMs + 999) ~/ 1000;
    final isMyTurn = value['yourTurn'] == true;
    final sub = value['sub']?.toString() ?? '';
    final reveal = sub == 'reveal';
    final urgencyThreshold = sub == 'answering'
        ? 5000
        : sub == 'reading'
            ? 2000
            : 0;
    final urgent = remainingMs > 0 &&
        urgencyThreshold > 0 &&
        remainingMs <= urgencyThreshold;
    final timerColor = urgent ? Colors.red.shade700 : Colors.teal.shade800;
    final progress =
        totalMs <= 0 ? 0.0 : (remainingMs / totalMs).clamp(0.0, 1.0).toDouble();
    final event = _latestEvent(value);
    final wrongFeedback = _isWrongEvent(event);
    final correctFeedback = event.contains('إجابة صحيحة!');
    final round = (value['round'] as num?)?.toInt() ?? 0;

    String timerLabel;
    if (sub == 'reading') {
      timerLabel = 'وقت قراءة السؤال';
    } else if (sub == 'answering') {
      timerLabel = 'الوقت المتبقي للإجابة';
    } else {
      timerLabel = 'تظهر النتيجة التالية خلال';
    }

    return [
      Text(
        'السؤال ${_arabicDigits(round)} من ${_arabicDigits((value['total'] as num?)?.toInt() ?? 0)}',
        textAlign: TextAlign.center,
        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
      ),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Text(
            '${you['name']}: ${you['score']}   ⚔   ${opponent?['name'] ?? 'المنافس'}: ${opponent?['score'] ?? 0}',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
          ),
        ),
      ),
      Text(
        value['status']?.toString() ?? '',
        textAlign: TextAlign.center,
        style: const TextStyle(color: Colors.teal, fontWeight: FontWeight.bold),
      ),
      if (wrongFeedback) _feedbackBanner(event, isCorrect: false),
      if (!wrongFeedback && correctFeedback)
        _feedbackBanner(event, isCorrect: true),
      const SizedBox(height: 8),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: urgent ? Colors.red.shade50 : Colors.teal.shade50,
          border: Border.all(color: timerColor, width: urgent ? 2.5 : 1.5),
          borderRadius: BorderRadius.circular(18),
        ),
        child: Column(
          children: [
            Text(
              timerLabel,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: timerColor,
                fontSize: 17,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 2),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                Text(
                  _arabicDigits(secondsLeft),
                  style: TextStyle(
                    color: timerColor,
                    fontSize: 52,
                    height: 1.1,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  'ثانية',
                  style: TextStyle(
                    color: timerColor,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            if (urgent)
              Text(
                'أسرع! الوقت يوشك على الانتهاء',
                style: TextStyle(
                  color: Colors.red.shade800,
                  fontWeight: FontWeight.bold,
                ),
              ),
          ],
        ),
      ),
      const SizedBox(height: 8),
      ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: LinearProgressIndicator(
          value: progress,
          minHeight: 12,
          color: timerColor,
          backgroundColor: timerColor.withOpacity(0.16),
        ),
      ),
      const SizedBox(height: 16),
      if (question == null)
        const Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            '🔒 السؤال عند المنافس الآن. إذا أخطأ أو انتهى وقته يعود السؤال إليك.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 20, height: 1.8),
          ),
        )
      else ...[
        Text(
          question['text']?.toString() ?? '',
          style: const TextStyle(
              fontSize: 23, fontWeight: FontWeight.bold, height: 1.7),
        ),
        const SizedBox(height: 16),
        ...List.generate((question['options'] as List).length, (i) {
          final correctIndex = (question['correctIndex'] as num?)?.toInt();
          final wrongChoice = _wrongRound == round && _wrongOption == i;
          final correctChoice = reveal && correctIndex == i;
          final choiceColor = wrongChoice
              ? Colors.red.shade700
              : correctChoice
                  ? Colors.green.shade700
                  : Colors.teal.shade400;
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: OutlinedButton(
              style: OutlinedButton.styleFrom(
                backgroundColor: wrongChoice
                    ? Colors.red.shade100
                    : correctChoice
                        ? Colors.green.shade100
                        : null,
                side: BorderSide(
                    color: choiceColor,
                    width: wrongChoice || correctChoice ? 2 : 1),
                padding: const EdgeInsets.all(16),
              ),
              onPressed: isMyTurn && sub == 'answering'
                  ? () => action('answer', {
                        'option': i,
                        'qi': round - 1,
                      })
                  : null,
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      '${['أ', 'ب', 'ج', 'د'][i]}) ${question['options'][i]}',
                      textAlign: TextAlign.right,
                      style: TextStyle(
                        fontSize: 18,
                        color: wrongChoice
                            ? Colors.red.shade900
                            : correctChoice
                                ? Colors.green.shade900
                                : null,
                        fontWeight: wrongChoice || correctChoice
                            ? FontWeight.bold
                            : null,
                      ),
                    ),
                  ),
                  if (wrongChoice)
                    Icon(Icons.close_rounded,
                        color: Colors.red.shade800, size: 30),
                  if (!wrongChoice && correctChoice)
                    Icon(Icons.check_circle_rounded,
                        color: Colors.green.shade800, size: 28),
                ],
              ),
            ),
          );
        }),
        if (isMyTurn && sub == 'reading')
          btn('قرأت السؤال — ابدأ المؤقت', () => action('begin')),
        if (reveal)
          Card(
            color: Colors.green.shade50,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                '💡 ${question['explanation'] ?? ''}',
                style: const TextStyle(fontSize: 17, height: 1.7),
              ),
            ),
          ),
      ],
      const SizedBox(height: 16),
      ...((value['events'] as List?) ?? const []).map((item) => Text('• $item',
          style: const TextStyle(
              fontSize: 13, color: Colors.blueGrey, height: 1.8))),
    ];
  }
}
