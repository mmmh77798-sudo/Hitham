import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:lughz_haitham/team_duel.dart';

void main() {
  testWidgets('team mode setup shows create and shared-code join flows',
      (tester) async {
    await tester.pumpWidget(
      const MaterialApp(home: TeamDuelPage()),
    );

    expect(find.text('فريق العباقرة'), findsOneWidget);
    expect(find.text('أنشئ غرفة فريقية واحصل على رمز'), findsOneWidget);
    expect(find.text('انضم إلى الغرفة بالفريق المختار'), findsOneWidget);
    expect(find.text('رمز الغرفة المشتركة'), findsOneWidget);
    expect(find.text('اختر فريقك'), findsOneWidget);
    await tester.tap(find.byType(DropdownButtonFormField<String>));
    await tester.pumpAndSettle();
    expect(find.text('الفريق الأحمر'), findsWidgets);
    expect(find.text('الفريق الأزرق'), findsOneWidget);
  });
}
